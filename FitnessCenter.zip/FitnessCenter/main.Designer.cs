﻿namespace FitnessCenter
{
    partial class main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.admission = new System.Windows.Forms.ToolStripMenuItem();
            this.admissionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.employee = new System.Windows.Forms.ToolStripMenuItem();
            this.salary = new System.Windows.Forms.ToolStripMenuItem();
            this.offers = new System.Windows.Forms.ToolStripMenuItem();
            this.users = new System.Windows.Forms.ToolStripMenuItem();
            this.nutrition = new System.Windows.Forms.ToolStripMenuItem();
            this.payments = new System.Windows.Forms.ToolStripMenuItem();
            this.reports = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.admission,
            this.employee,
            this.salary,
            this.offers,
            this.users,
            this.nutrition,
            this.payments,
            this.reports});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // admission
            // 
            this.admission.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.admissionToolStripMenuItem});
            this.admission.Name = "admission";
            this.admission.Size = new System.Drawing.Size(76, 20);
            this.admission.Text = "ADMISSION";
            this.admission.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // admissionToolStripMenuItem
            // 
            this.admissionToolStripMenuItem.Name = "admissionToolStripMenuItem";
            this.admissionToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.admissionToolStripMenuItem.Text = "Admission";
            // 
            // employee
            // 
            this.employee.Name = "employee";
            this.employee.Size = new System.Drawing.Size(70, 20);
            this.employee.Text = "EMPLOYEE";
            this.employee.Click += new System.EventHandler(this.employee_Click);
            // 
            // salary
            // 
            this.salary.Name = "salary";
            this.salary.Size = new System.Drawing.Size(57, 20);
            this.salary.Text = "SALARY";
            this.salary.Click += new System.EventHandler(this.salary_Click);
            // 
            // offers
            // 
            this.offers.Name = "offers";
            this.offers.Size = new System.Drawing.Size(58, 20);
            this.offers.Text = "OFFERS";
            this.offers.Click += new System.EventHandler(this.offers_Click);
            // 
            // users
            // 
            this.users.Name = "users";
            this.users.Size = new System.Drawing.Size(51, 20);
            this.users.Text = "USERS";
            this.users.Click += new System.EventHandler(this.users_Click);
            // 
            // nutrition
            // 
            this.nutrition.Name = "nutrition";
            this.nutrition.Size = new System.Drawing.Size(75, 20);
            this.nutrition.Text = "NUTRITION";
            this.nutrition.Click += new System.EventHandler(this.nutrition_Click);
            // 
            // payments
            // 
            this.payments.Name = "payments";
            this.payments.Size = new System.Drawing.Size(71, 20);
            this.payments.Text = "PAYMENTS";
            this.payments.Click += new System.EventHandler(this.payments_Click);
            // 
            // reports
            // 
            this.reports.Name = "reports";
            this.reports.Size = new System.Drawing.Size(65, 20);
            this.reports.Text = "REPORTS";
            this.reports.Click += new System.EventHandler(this.reports_Click);
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "main";
            this.Text = "MAIN";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.main_FormClosing);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem admission;
        private System.Windows.Forms.ToolStripMenuItem admissionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem employee;
        private System.Windows.Forms.ToolStripMenuItem salary;
        private System.Windows.Forms.ToolStripMenuItem offers;
        private System.Windows.Forms.ToolStripMenuItem users;
        private System.Windows.Forms.ToolStripMenuItem nutrition;
        private System.Windows.Forms.ToolStripMenuItem payments;
        private System.Windows.Forms.ToolStripMenuItem reports;
    }
}