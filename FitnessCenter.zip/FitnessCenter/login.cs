﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FitnessCenter
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void usertype_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cancel_Click(object sender, EventArgs e)
        {
            ut.Text = "NONE";
            un.Text = "";
            pw.Text = "";
        }

        private void log_Click(object sender, EventArgs e)
        {
            string username, password;
            username = "prajakta";
            password = "23269";

            if (string.IsNullOrWhiteSpace(un.Text))
            {
                MessageBox.Show("Please input proper Username...!");
            }
            if (string.IsNullOrWhiteSpace(ut.Text) || ut.Text == "NONE")
            {
                MessageBox.Show("Please input proper Usertype...!");
            }
            if (string.IsNullOrWhiteSpace(pw.Text))
            {
                MessageBox.Show("Please input proper Password...!");
            }
            else if ((un.Text == username) && (pw.Text == password))
            {
                //MessageBox.Show("Welcome" + "!");
                main frm = new main();
                this.Hide();
                frm.Show();
            }
            else if ((un.Text != username) && (pw.Text != password))
            {
                MessageBox.Show("Please input proper Username and/or Password...!");
            }
        }

        private void Login_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            ut.Text = "NONE";
        }
    }
}
