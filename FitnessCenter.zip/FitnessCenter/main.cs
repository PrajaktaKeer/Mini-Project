﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FitnessCenter
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void main_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Admission f = new Admission();
            this.Hide();
            f.Show();
        }

        private void employee_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void salary_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void offers_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void users_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void nutrition_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void payments_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void reports_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
